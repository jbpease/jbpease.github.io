"""
Input columns from standard swipe output:
0-Query id			1-Subject id		2-% identity	3-alignment length
4-mismatches		5-gap openings		6-q. start		7-q. end
8-s. start			9-s. end			10-e-value		11-bit score

Output columns:
0-Query id
1-Subject id
2-evalue
"""

PERC_IDENTITY_CUTOFF = 0.7
#ALIGNMENT_LEN_CUTOFF = 0
BITSCORE_CUTOFF = 100
#MAX_NUM_HITS = 20 #number of top hits in outfile

import os,sys
import math

if __name__ == "__main__":
	if len(sys.argv) != 2:
		print "usage: swipe_to_mcl.py filename"
		sys.exit()
	
	infile = open(sys.argv[1],"r")
	outfile = open(sys.argv[1]+".filtered","w")
	last_query = ""
	#count = 0
	
	for line in infile:
		if len(line) > 3:
			spls = line.strip().split("\t")
			query = spls[0]
			hit = spls[1].lstrip("lcl|")
			bitscore = float(spls[11])
			#ignore self hits and low score hits
			if query == hit or bitscore < BITSCORE_CUTOFF:
				continue 
			if spls[10] == "0.0" or spls[10] == "0":
				evalue = 300 #max for swipe output
			else:
				evalue = -math.log10(float(spls[10]))
			
			#process hits
			#if count < MAX_NUM_HITS or query != last_query:
				#if query != last_query:
				#	count = 0
			outfile.write(query+" "+hit+" "+str(evalue)+"\n")
			#count += 1
			#last_query = query
	infile.close()
	outfile.close()
