import sys,os
import sequence,seq_reader

if __name__ =="__main__":
	if len(sys.argv) != 4:
		print "usage: write_fasta_files_from_clusters_simple.py .fa clusters outDIR"
		sys.exit()
	
	print "Reading clusters"
	homologDICT = {} #key is transcript id, value is homolog id 1,2,...
	infile = open(sys.argv[2],"rU")
	clusterID = 1
	for line in infile:
		#get members of a cluster in a list
		memberlist = line.strip().split('\t')
		for i in memberlist:
			homologDICT[i] = clusterID
		clusterID += 1
	infile.close()
	
	print "Reading the fasta file"
	seqs = seq_reader.read_fasta_file(sys.argv[1])
	outDICT = {} #key is clusterID, value is a list of fasta output
	for seq_record in seqs:
		seqid = str(seq_record.lab)
		seq = str(seq_record.seq)
		try: clusterID = homologDICT[seqid]
		except: continue #seq that only hit itself in blast will not be in the dict
		if clusterID not in outDICT:
			outDICT[clusterID] = []
		outDICT[clusterID].append(">"+seqid+"\n"+seq+"\n")

	print "Writing fasta files"
	for clusterID in outDICT:
		out = outDICT[clusterID]
		outfile = open(sys.argv[3]+"/cluster"+str(clusterID)+".fa","w")
		for i in out: outfile.write(i)
		outfile.close()
