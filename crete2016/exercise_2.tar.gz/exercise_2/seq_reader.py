import sequence

def read_fasta_file(filename):
	fl = open(filename,"r")
	maind = [] #maind[key] = value
	templab = ""
	tempseq = ""
	first = True
	for i in fl:
		if i[0] == ">":
			if first == True:
				first = False
			else:#if not first store lastseq read
				ts = sequence.Sequence(templab,tempseq)
				maind.append(ts)
			templab = i.strip()[1:]
			tempseq = ""
		else:
			tempseq = tempseq + i.strip()
	fl.close()
	ts = sequence.Sequence(templab,tempseq)
	maind.append(ts)
	return maind

def read_fastq_file(filename):
	maind = []
	fl = open(filename,"r")
	i = fl.readline()
	while len(i) > 0:
		name = i[1:].strip()
		seq = fl.readline().strip()
		junk  = fl.readline().strip()
		qual = fl.readline().strip()
		ts = sequence.Sequence(name,seq)
		ts.set_qualstr(qual)
		maind.append(ts)
		i = fl.readline()
	fl.close()
	return maind