"""
convert cleaned alignment files end with cln to relaxed phylip format
"""

import os,sys

if __name__ == "__main__":
	if len(sys.argv) != 3:
		print "python fasta2phylip.py infasta outfile"
		sys.exit(0)
	longest_id = 1 #hate that phylip requires this! Why not using fasta!
	seqDICT = {} #key is seq id, value is seq
	infile = open(sys.argv[1],"rU")
	seqid = ""
	for line in infile:
		line = line.strip()
		if len(line) > 0:
			if line[0] == ">":
				if seqid != "": seqDICT[seqid] = seq
				seqid,seq = line[1:],""
				longest_id = max(longest_id,len(seqid))
			else: seq += line.strip()
	seqDICT[seqid] = seq #add the last record
	infile.close()
	
	#output relaxed phylip file
	outfile = open(sys.argv[2], "w")
	aligned_length = len(seqDICT[seqDICT.keys()[0]])
	outfile.write(str(len(seqDICT))+" "+str(aligned_length)+"\n")
	for i in seqDICT: #loop through seq records
		outfile.write(i)
		for j in range(longest_id-len(i)+1): outfile.write(" ")
		outfile.write(seqDICT[i]+"\n")
	outfile.close()
