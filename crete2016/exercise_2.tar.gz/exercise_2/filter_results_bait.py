import seq_reader
import sys

"""
current.fasta will be the file that has the current sequences that we don't want to 
repeat. In general it will have the last _ split as the sequence accession. 

blast table is from 
blastn -db current2012.db -query ../cary.fasta -perc_identity 20 -evalue 10000 -num_threads 2 -max_target_seqs 2 -out cary.fasta.rawblastn -outfmt '6 qseqid qlen sseqid slen frames pident nident length mismatch gapopen qstart qend sstart send evalue bitscore'

cary.fasta is the source from genbank
cary.fasta.table is the information from the dump from get_subset
"""
blast_cutoff = 350
genename = "atpB"
if __name__ == "__main__":
    if len(sys.argv) != 4:
        print "python "+sys.argv[0]+" blast.table cary.fasta cary.fasta.table"
        sys.exit(0)
    tbl = open(sys.argv[1],"r")
    keepids = []
    tkeepids = []
    starts = {}
    stops = {}
    revs = {}
    for i in tbl:
        spls = i.strip().split("\t")
        st = int(spls[12])
        sp = int(spls[13])
        revs[spls[0]] = False
        if st > sp:
            revs[spls[0]] = True
            t = st
            st = sp
            sp = t
        starts[spls[0]] = st 
        stops[spls[0]] = sp
        if sp - st < blast_cutoff:
            continue
        tkeepids.append(spls[0])
    tkeepids = list(set(tkeepids))
    tbl.close()
    ktbl = open(sys.argv[3],"r")
    dkt = {}
    names = {} #key is id, value is name
    for i in ktbl:
        spls = i.strip().split("\t")
        if spls[3] in tkeepids and genename in i and "UNVERIFIED" not in i:
            keepids.append(spls[3])
            names[spls[3]]  = "_".join(spls[4].split(" ")[0:2])
    ktbl.close()
    #print len(keepids)
    #sys.exit(0)
    cur = seq_reader.read_fasta_file(sys.argv[2])
    for i in cur:
        l = i.lab
        if l in keepids:
            if len(i.seq) > 400:
                start = starts[l]
                stop = stops[l]
                if start > 400:
                    start = start#-400
                else:
                    start = start#0
                i.seq = i.seq[start:stop+400]
            if revs[l] == True:
                i.seq = i.seq[::-1]
            i.lab = names[i.lab]+"_"+i.lab
            print i.get_fasta()


