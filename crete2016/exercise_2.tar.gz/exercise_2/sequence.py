
class Sequence:
	def __init__(self, inlab, inseq):
		self.lab = inlab
		self.seq = inseq
		self.qualstr = ""
		self.qualarr = []
	
	def set_qualstr(self, qual):
		self.qualstr = qual
		for j in qual:
			self.qualarr.append(ord(j)-33)
	
	def get_fancy(self):
		y = "Sequence label: "+self.lab+"\nSequence: "+self.seq+"\n"
		return y

	def get_fasta(self):
		return ">"+self.lab+"\n"+self.seq+"\n"