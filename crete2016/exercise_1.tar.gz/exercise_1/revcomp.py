from seq_reader import *

compdict = {'A':'T','C':'G','G':'C','T':'A','N':'N'}

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print "python revcomp.py infile outfile"
        sys.exit(0)
    seq1 = read_fasta_file(sys.argv[1])
    outfile = open(sys.argv[2],"w")
    for j in seq1:
        rets = ""
        for i in j.seq[::-1]:
            rets += compdict[i]
        outfile.write(">"+j.name+"\n")
        outfile.write(rets+"\n")
    outfile.close()
