from pairwise_alignment import *
from seq_reader import *

sc_mat = read_scoring_matrix("EDNAFULL")
gap = -2

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print "python run.py seq1.fasta seq2.fasta"
        sys.exit(0)
    seq1 = read_fasta_file(sys.argv[1])[0]
    seq2 = read_fasta_file(sys.argv[2])[0]
    sw_pairwise(seq1.seq,seq2.seq,gap,sc_mat,verbose=False)
