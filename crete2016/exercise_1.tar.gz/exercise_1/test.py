from pairwise_alignment import *
from seq_reader import *

sc_mat = read_scoring_matrix("EDNAFULL")
g = 0 #gap penalty
m,mm = nwg_pairwise("GAATTCAGTTA","GGATCGA",g,sc_mat,verbose=False)
#m,mm = nwg_pairwise("ACGTTAGA","CGTTGAA",g,sc_mat,verbose=False)
#m,mm = sw_pairwise("ACGTTAGA","CGTTGAA",g,sc_mat,verbose=False)
#m,mm = nwg_pairwise("TGCTCGTA","TTCATA",g,sc_mat,verbose=False)
#m,mm = sw_pairwise("TGCTCGTA","TTCATA",g,sc_mat,verbose=False)

#sc_mat = read_scoring_matrix("BLOSUM50")
#m,mm = nwg_pairwise("HEAGAWGHEE","PAWHEAE",g,sc_mat,verbose=False)
#m,mm = sw_pairwise("HEAGAWGHEE","PAWHEAE",g,sc_mat,verbose=False)

print "match:",m,"mismatch:",mm
